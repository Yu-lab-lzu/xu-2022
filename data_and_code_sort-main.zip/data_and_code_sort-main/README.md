# data_and_code_sort
The data and code for the paper: Avalanche criticality in individuals, fluid intelligence and working memory  

Some data with strict-access of HCP were not shared.
If you have any questions, please contact me: longzhou960316@gmail.com


note: 2022-02-05
reorder the code, but as the data biger than 25M, the signals data did not upload in git hub

update:2022-04-09
